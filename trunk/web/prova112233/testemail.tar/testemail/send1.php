<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<html>
 <head>
  <title>prova</title>
 </head>
 <body >

<BR>

<form method="post" enctype="multipart/form-data" action="send2.php">
<input type="text" name="email_iscritto" value="" /> email <br>
<input type="submit" value="iscrizione" /><br>
</form>

</body>
</html>


